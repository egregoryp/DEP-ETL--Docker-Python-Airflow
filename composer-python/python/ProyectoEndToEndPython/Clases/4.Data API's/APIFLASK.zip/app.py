from api import app
from utils.db import db

from routes.enunciados import *

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
