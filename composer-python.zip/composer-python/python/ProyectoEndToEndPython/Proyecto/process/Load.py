import io
import os
from io import StringIO
from azure.storage.blob import ContainerClient
from google.cloud.storage import Client
import pandas as pd

class Load():
    
    pass