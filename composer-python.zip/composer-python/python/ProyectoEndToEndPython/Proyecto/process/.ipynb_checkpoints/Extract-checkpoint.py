import os
from io import StringIO
from google.cloud.storage import Client
from azure.storage.blob import ContainerClient
from pymongo import MongoClient
import sqlalchemy as db
from sqlalchemy import text
import pandas as pd
from pandas import DataFrame

class Extract():
    def __init__(self) -> None:
        self.process = 'Extract Process'

    def read_cloud_storage(self, bucketName, fileName):

        os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/user/app/fresh-bloom-372404-c792e5b41e7f.json"
        client = Client()
        bucket = client.get_bucket(bucketName)
        blob = bucket.get_blob(fileName)
        downloaded_file = blob.download_as_text(encoding="utf-8")
        df = pd.read_csv(StringIO(downloaded_file))
        return df

    def read_mongodb(self, databaseName, collectionName):
        
        CONNECTION_STRING = "mongodb+srv://m001-student:mCxRoc3yh6nf2Xyv@sandbox.okkbl.mongodb.net/?retryWrites=true&w=majority"
        client = MongoClient(CONNECTION_STRING)
        dbname = client[databaseName]
        collection_name = dbname[collectionName]
        customers = collection_name.find({})
        df = DataFrame(customers)
        return df
    
    def read_mysql(self, databaseName, tableName):
        
        engine = db.create_engine(f"mysql://root:root$@localhost/{databaseName}")
        conn = engine.connect()
        sql_query = pd.read_sql_query(text(f"SELECT * FROM {tableName}"), conn) # sqlalchemy 2.0.2

        df = pd.DataFrame(sql_query)
        return df

    def read_adls(self, containerName, fileName):
        
        conn_str = "BlobEndpoint=https://adlsdatapath.blob.core.windows.net/;QueueEndpoint=https://adlsdatapath.queue.core.windows.net/;FileEndpoint=https://adlsdatapath.file.core.windows.net/;TableEndpoint=https://adlsdatapath.table.core.windows.net/;SharedAccessSignature=sv=2021-12-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2023-06-01T10:33:16Z&st=2023-03-17T02:33:16Z&spr=https&sig=14f9a42cRquiSn5bpy4dbLbWVeH2tRonE2AsedPIluw%3D"
        container = containerName
        container_client = ContainerClient.from_connection_string(
            conn_str=conn_str, 
            container_name=container
        )
        downloaded_blob = container_client.download_blob(fileName)
        df = pd.read_csv(StringIO(downloaded_blob.content_as_text()))
        return df

