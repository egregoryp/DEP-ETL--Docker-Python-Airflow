import io
import os
from io import StringIO
from azure.storage.blob import ContainerClient
from google.cloud.storage import Client
import pandas as pd

class Load():
    
    def __init__(self) -> None:
        self.process = 'Load Process'

    def load_to_adls(self, df, containerName, blobName):

        conn_str = "BlobEndpoint=https://adlsdatapath.blob.core.windows.net/;QueueEndpoint=https://adlsdatapath.queue.core.windows.net/;FileEndpoint=https://adlsdatapath.file.core.windows.net/;TableEndpoint=https://adlsdatapath.table.core.windows.net/;SharedAccessSignature=sv=2021-12-02&ss=bfqt&srt=sco&sp=rwdlacupyx&se=2023-06-01T10:33:16Z&st=2023-03-17T02:33:16Z&spr=https&sig=14f9a42cRquiSn5bpy4dbLbWVeH2tRonE2AsedPIluw%3D"
        container = containerName
        container_client = ContainerClient.from_connection_string(
            conn_str=conn_str, 
            container_name=container
        )
        output = io.StringIO()
        output = df.to_csv(encoding = "utf-8", index=False)
        container_client.upload_blob(blobName, output, overwrite=True, encoding='utf-8')
    
    def load_to_cloud_storage(self, df, bucketName, fileName): #bucketName= Datalake_krm, filename = "Alex/customer"
        
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"]="/user/app/fresh-bloom-372404-c792e5b41e7f.json"
        client = Client()
        bucket = client.get_bucket(bucketName)
        bucket.blob(fileName).upload_from_string(df.to_csv(index=False), 'text/csv',)
    
    def load_to_mysql():
        pass

    def  load_to_bigquery():
        pass