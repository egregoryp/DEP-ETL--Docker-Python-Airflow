
from pandasql import sqldf
pysqldf = lambda q: sqldf(q, locals()) 

class Transform():
    
    pass